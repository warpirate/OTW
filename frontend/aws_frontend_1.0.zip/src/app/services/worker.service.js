import axios from 'axios';
import { API_BASE_URL } from '../config';
import AuthService from './auth.service';

const apiClient = axios.create({
  baseURL: `${API_BASE_URL}/api/worker-management`,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add a request interceptor to include JWT token in the headers
apiClient.interceptors.request.use(
  (config) => {
    const token = AuthService.getToken('worker');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 || error.response?.status === 403) {
      // Use AuthService for proper token cleanup
      AuthService.logout(null, 'worker');
      
      // Redirect to login if not already there
      if (!window.location.pathname.includes('/worker/login')) {
        window.location.href = '/worker/login';
      }
    }
    return Promise.reject(error);
  }
);

class WorkerService {
  /**
   * Register a new worker
   */
  static async registerWorker(userData) {
    try {
      const response = await apiClient.post('/worker/register', userData);
      return response.data;
    } catch (error) {
      throw error;
    }
  }
  
  /**
   * Get worker profile
   */
  static async getProfile() {
    try {
      const response = await apiClient.get('/worker/profile');
      return response.data;
    } catch (error) {
      throw error;
    }
  }
  
  /**
   * Update worker profile
   */
  static async updateProfile(updateData) {
    try {
      const response = await apiClient.put('/worker/profile', updateData);
      return response.data;
    } catch (error) {
      console.error('Error updating worker profile:', error);
      throw new Error(error.response?.data?.message || 'Failed to update profile');
    }
  }
  
  /**
   * Get dashboard stats
   */
  static async getDashboardStats() {
    try {
      const response = await apiClient.get('/worker/dashboard-stats');
      return response.data;
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      throw new Error(error.response?.data?.message || 'Failed to load stats');
    }
  }
  
    // Alias to reuse existing axios client for settings endpoints
  static _client = apiClient;

  // Convert backend flat schema to frontend nested schema
  static _toFrontendSettings(data) {
    const notifications = {
      newJobAlerts: data.notify_on_job_alerts ?? true,
      messageAlerts: data.notify_on_messages ?? true,
      paymentAlerts: data.notify_on_payments ?? true,
      promotionalEmails: data.notify_by_email ?? false,
      smsNotifications: data.notify_by_sms ?? false,
      pushNotifications: data.notify_by_push ?? true
    };

    const availability = {
      auto_accept_jobs: data.auto_accept_jobs ?? false,
      max_jobs_per_day: data.max_jobs_per_day ?? 5,
      working_hours: {
        start: data.working_hours_start ?? '09:00',
        end: data.working_hours_end ?? '18:00'
      },
      weekend_work: data.allow_weekend_work ?? true,
      holiday_work: data.allow_holiday_work ?? false
    };

    const privacy = {
      show_profile_to_customers: data.profile_visibility === 'public',
      show_rating_publicly: data.display_rating ?? true,
      allow_direct_contact: data.allow_direct_contact ?? true,
      share_location_data: data.location_sharing_mode !== 'off'
    };

    const preferences = {
      language: data.preferred_language ?? 'en',
      currency: data.preferred_currency ?? 'INR',
      distance_unit: data.distance_unit ?? 'km',
      time_format: data.time_format ?? '24h'
    };

    return {
      ...data, // keep original flat fields for convenience
      notifications,
      availability,
      privacy,
      preferences
    };
  }

  // Convert frontend nested schema back to backend flat schema
  static _toBackendSettings(settings) {
    return {
      // Notifications
      notify_on_job_alerts: settings.notifications?.newJobAlerts ?? settings.notify_on_job_alerts,
      notify_on_messages: settings.notifications?.messageAlerts ?? settings.notify_on_messages,
      notify_on_payments: settings.notifications?.paymentAlerts ?? settings.notify_on_payments,
      notify_by_email: settings.notifications?.promotionalEmails ?? settings.notify_by_email,
      notify_by_sms: settings.notifications?.smsNotifications ?? settings.notify_by_sms,
      notify_by_push: settings.notifications?.pushNotifications ?? settings.notify_by_push,

      // Availability
      auto_accept_jobs: settings.availability?.auto_accept_jobs ?? settings.auto_accept_jobs,
      max_jobs_per_day: settings.availability?.max_jobs_per_day ?? settings.max_jobs_per_day,
      allow_weekend_work: settings.availability?.weekend_work ?? settings.allow_weekend_work,
      allow_holiday_work: settings.availability?.holiday_work ?? settings.allow_holiday_work,

      // Privacy
      profile_visibility: settings.privacy?.show_profile_to_customers ? 'public' : 'platform_only',
      display_rating: settings.privacy?.show_rating_publicly ?? settings.display_rating,
      allow_direct_contact: settings.privacy?.allow_direct_contact ?? settings.allow_direct_contact,
      location_sharing_mode: settings.privacy?.share_location_data ? 'on_job' : 'off',

      // Preferences
      preferred_language: settings.preferences?.language ?? settings.preferred_language,
      preferred_currency: settings.preferences?.currency ?? settings.preferred_currency,
      distance_unit: settings.preferences?.distance_unit ?? settings.distance_unit,
      time_format: settings.preferences?.time_format ?? settings.time_format,

      // Working hours (optional extension)
      working_hours_start: settings.availability?.working_hours?.start,
      working_hours_end: settings.availability?.working_hours?.end
    };
  }

  static async getSettings() {
    try {
      const { data } = await WorkerService._client.get('/worker/settings');
      return WorkerService._toFrontendSettings(data);
    } catch (error) {
      console.error('Error fetching settings:', error);
      throw error;
    }
  }

  // Update system settings
  static async updateSettings(settingsData) {
    try {
      const backendPayload = WorkerService._toBackendSettings(settingsData);
      const response = await WorkerService._client.put('/worker/settings', backendPayload);
      return response.data;
    } catch (error) {
      console.error('Error updating settings:', error);
      throw error;
    }
  }

  // Update specific setting category
  static async updateCategorySettings(category, settings) {
    try {
      const response = await WorkerService._client.put(`/worker/settings/${category}`, settings);
      return response.data;
    } catch (error) {
      console.error('Error updating category settings:', error);
      throw error;
    }
  }

  // Reset settings to default
  static async resetSettings(category = null) {
    try {
      const url = category ? `/worker/settings/reset/${category}` : '/worker/settings/reset';
      const response = await WorkerService._client.post(url);
      return response.data;
    } catch (error) {
      console.error('Error resetting settings:', error);
      throw error;
    }
  }

  /**
   * Booking Requests Management
   */
  
  /**
   * Get booking requests for worker
   */
  static async getBookingRequests(status = null, page = 1, limit = 20) {
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: limit.toString()
      });
      
      if (status) {
        params.append('status', status);
      }
      
      const response = await WorkerService._client.get(`/worker/booking-requests?${params}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching booking requests:', error);
      throw new Error(error.response?.data?.message || 'Failed to load booking requests');
    }
  }
  
  /**
   * Get booking requests using cursor-based pagination
   */
  static async getBookingRequestsCursor({ status = null, cursor = null, limit = 20 } = {}) {
    try {
      const params = new URLSearchParams({
        limit: limit.toString(),
        mode: 'cursor'
      });
      if (status) params.append('status', status);
      if (cursor) params.append('cursor', String(cursor));
      const { data } = await WorkerService._client.get(`/worker/booking-requests?${params}`);
      return data;
    } catch (error) {
      console.error('Error fetching booking requests (cursor):', error);
      throw new Error(error.response?.data?.message || 'Failed to load booking requests');
    }
  }

  /**
   * Get counts for booking requests by status
   */
  static async getBookingRequestCounts() {
    try {
      const { data } = await WorkerService._client.get('/worker/booking-requests/counts');
      return data;
    } catch (error) {
      console.error('Error fetching booking request counts:', error);
      throw new Error(error.response?.data?.message || 'Failed to load counts');
    }
  }
  
  /**
   * Update booking request status
   */
  static async updateBookingRequest(requestId, status, reason = null) {
    try {
      const response = await WorkerService._client.put(`/worker/booking-requests/${requestId}`, {
        status,
        reason
      });
      return response.data;
    } catch (error) {
      console.error('Error updating booking request:', error);
      throw new Error(error.response?.data?.message || 'Failed to update booking request');
    }
  }

  /**
   * Get dashboard stats
   */
  static async getDashboardStats() {
    try {
      const response = await WorkerService._client.get('/worker/dashboard-stats');
      return response.data;
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      throw new Error(error.response?.data?.message || 'Failed to load dashboard stats');
    }
  }

  /**
   * Get assigned bookings for worker
   */
  static async getAssignedBookings(page = 1, limit = 10, status = null) {
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: limit.toString()
      });
      
      if (status) {
        params.append('status', status);
      }

      const response = await WorkerService._client.get(`/worker/assigned-bookings?${params}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching assigned bookings:', error);
      throw new Error(error.response?.data?.message || 'Failed to load assigned bookings');
    }
  }

  /**
   * Get recent bookings related to the provider's categories
   */
  static async getRecentBookings(limit = 5) {
    try {
      const params = new URLSearchParams({ limit: String(limit) });
      const response = await WorkerService._client.get(`/worker/recent-bookings?${params}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching recent bookings:', error);
      throw new Error(error.response?.data?.message || 'Failed to load recent bookings');
    }
  }

  /**
   * Cancel assigned booking
   */
  static async cancelBooking(bookingId, cancellationReason = null) {
    try {
      const response = await WorkerService._client.put(`/worker/bookings/${bookingId}/cancel`, {
        cancellation_reason: cancellationReason
      });
      return response.data;
    } catch (error) {
      console.error('Error cancelling booking:', error);
      throw new Error(error.response?.data?.message || 'Failed to cancel booking');
    }
  }

  /**
   * Admin Functions
   */
  
  /**
   * Get all workers (Admin only)
  //  */
  // static async getAllWorkers(page = 1, limit = 20, filters = {}) {
  //   try {
  //     const params = new URLSearchParams({
  //       page: page.toString(),
  //       limit: limit.toString(),
  //       ...filters
  //     });
      
  //     const response = await apiClient.get(`/worker/all?${params}`);
  //     return response.data;
  //   } catch (error) {
  //     throw error;
  //   }
  // }
  
  // /**
  //  * Get specific worker by ID (Admin only)
  //  */
  // static async getWorkerById(workerId) {
  //   try {
  //     const response = await apiClient.get(`/worker/${workerId}`);
  //     return response.data;
  //   } catch (error) {
  //     throw error;
  //   }
  // }
  
  // /**
  //  * Update worker verification status (Admin only)
  //  */
  // static async updateVerificationStatus(workerId, verified) {
  //   try {
  //     const response = await apiClient.patch(`/worker/${workerId}/verify`, {
  //       verified
  //     });
  //     return response.data;
  //   } catch (error) {
  //     throw error;
  //   }
  // }
  
  // /**
  //  * Update worker activity status (Admin only)
  //  */
  // static async updateActivityStatus(workerId, active) {
  //   try {
  //     const response = await apiClient.patch(`/worker/${workerId}/activity`, {
  //       active
  //     });
  //     return response.data;
  //   } catch (error) {
  //     throw error;
  //   }
  // }

  /**
   * Profile Picture Management
   */

  /**
   * Generate presigned URL for profile picture upload
   */
  static async getProfilePictureUploadUrl(fileName, contentType) {
    try {
      const response = await WorkerService._client.post('/worker/profile-picture/presign', {
        file_name: fileName,
        content_type: contentType
      });
      return response.data;
    } catch (error) {
      console.error('Error getting profile picture upload URL:', error);
      throw new Error(error.response?.data?.message || 'Failed to get upload URL');
    }
  }

  /**
   * Upload profile picture to S3 using presigned URL
   */
  static async uploadProfilePictureToS3(presignedUrl, file) {
    try {
      await fetch(presignedUrl, {
        method: 'PUT',
        body: file,
        headers: {
          'Content-Type': file.type
        }
      });
      return true;
    } catch (error) {
      console.error('Error uploading profile picture to S3:', error);
      throw new Error('Failed to upload profile picture');
    }
  }

  /**
   * Update profile picture URL in database
   */
  static async updateProfilePictureUrl(profilePictureUrl) {
    try {
      const response = await WorkerService._client.put('/worker/profile-picture', {
        profile_picture_url: profilePictureUrl
      });
      return response.data;
    } catch (error) {
      console.error('Error updating profile picture URL:', error);
      throw new Error(error.response?.data?.message || 'Failed to update profile picture');
    }
  }

  /**
   * Get presigned URL to view profile picture
   */
  static async getProfilePictureViewUrl() {
    try {
      const response = await WorkerService._client.get('/worker/profile-picture/presign');
      return response.data;
    } catch (error) {
      if (error.response?.status === 404) {
        return null; // No profile picture found
      }
      console.error('Error getting profile picture view URL:', error);
      throw new Error(error.response?.data?.message || 'Failed to get profile picture');
    }
  }

  /**
   * Delete profile picture
   */
  static async deleteProfilePicture() {
    try {
      const response = await WorkerService._client.delete('/worker/profile-picture');
      return response.data;
    } catch (error) {
      console.error('Error deleting profile picture:', error);
      throw new Error(error.response?.data?.message || 'Failed to delete profile picture');
    }
  }

  /**
   * Complete profile picture upload flow
   * @param {File} file - The image file to upload
   * @returns {Promise<string>} - The S3 URL of the uploaded image
   */
  static async uploadProfilePicture(file) {
    try {
      // Step 1: Get presigned URL
      const { upload_url, s3_key } = await this.getProfilePictureUploadUrl(
        file.name,
        file.type
      );

      // Step 2: Upload to S3
      await this.uploadProfilePictureToS3(upload_url, file);

      // Step 3: Construct S3 URL
      const s3Url = upload_url.split('?')[0]; // Remove query parameters

      // Step 4: Update database
      await this.updateProfilePictureUrl(s3Url);

      return s3Url;
    } catch (error) {
      console.error('Error in complete profile picture upload:', error);
      throw error;
    }
  }
  
}

export default WorkerService;
