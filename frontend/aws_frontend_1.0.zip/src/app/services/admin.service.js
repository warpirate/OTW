import axios from 'axios';
import { API_BASE_URL } from '../config';
import AuthService from './auth.service';

const apiClient = axios.create({
  baseURL: `${API_BASE_URL}/api/admin`,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add request interceptor to include JWT token
apiClient.interceptors.request.use(
  (config) => {
    const token = AuthService.getToken('admin') || AuthService.getToken('superadmin');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 || error.response?.status === 403) {
      // Clear tokens and redirect to login
      AuthService.logout();
      window.location.href = '/admin/login';
    }
    return Promise.reject(error);
  }
);

class AdminService {
  /**
   * Get all providers with pagination, search and filters
   */
  static async getProviders(params = {}) {
    try {
      const queryParams = new URLSearchParams();
      
      if (params.page) queryParams.append('page', params.page);
      if (params.limit) queryParams.append('limit', params.limit);
      if (params.search) queryParams.append('search', params.search);
      if (params.verified !== undefined) queryParams.append('verified', params.verified);
      if (params.active !== undefined) queryParams.append('active', params.active);

      const response = await apiClient.get(`/providers?${queryParams}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Get specific provider by ID
   */
  static async getProvider(id) {
    try {
      const response = await apiClient.get(`/providers/${id}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Update provider verification status
   */
  static async updateProviderVerification(id, verified) {
    try {
      const response = await apiClient.patch(`/providers/${id}/verify`, {
        verified
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Update provider details
   */
  static async updateProvider(id, providerData) {
    try {
      const response = await apiClient.put(`/providers/${id}`, providerData);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Delete provider
   */
  static async deleteProvider(id) {
    try {
      const response = await apiClient.delete(`/providers/${id}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Toggle provider active status
   */
  static async toggleProviderActive(id, active) {
    try {
      const response = await apiClient.patch(`/providers/${id}/toggle-active`, {
        active
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Approve provider
   */
  static async approveProvider(id) {
    return this.updateProviderVerification(id, true);
  }

  /**
   * Reject provider
   */
  static async rejectProvider(id) {
    return this.updateProviderVerification(id, false);
  }

  /**
   * Get provider banking details
   */
  static async getProviderBankingDetails(id) {
    try {
      const response = await apiClient.get(`/providers/${id}/banking-details`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Get provider documents
   */
  static async getProviderDocuments(id) {
    try {
      const response = await apiClient.get(`/providers/${id}/documents`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Get provider qualifications
   */
  static async getProviderQualifications(id) {
    try {
      const response = await apiClient.get(`/providers/${id}/qualifications`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Get provider driver details
   */
  static async getProviderDriverDetails(id) {
    try {
      const response = await apiClient.get(`/providers/${id}/driver-details`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Verify provider document
   */
  static async verifyProviderDocument(documentId, data) {
    try {
      const response = await apiClient.patch(`/providers/documents/${documentId}/verify`, data);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Verify banking details
   */
  static async verifyBankingDetails(bankingId, data) {
    try {
      const response = await apiClient.patch(`/providers/banking/${bankingId}/verify`, data);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Get provider services
   */
  static async getProviderServices(id) {
    try {
      const response = await apiClient.get(`/providers/${id}/services`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Get presigned GET URL for a provider document (admin-only)
   */
  static async getDocumentPresignedUrl(documentId) {
    try {
      const response = await apiClient.get(`/providers/documents/${documentId}/presign`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Verify qualification (approve/reject)
   */
  static async verifyQualification(qualificationId, data) {
    try {
      const response = await apiClient.patch(`/providers/qualifications/${qualificationId}/status`, data);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Get presigned URL for qualification certificate
   */
  static async getQualificationCertificatePresignedUrl(qualificationId) {
    try {
      const response = await apiClient.get(`/providers/qualifications/${qualificationId}/certificate`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Get all pending qualifications for admin review
   */
  static async getPendingQualifications(params = {}) {
    try {
      const queryParams = new URLSearchParams();
      
      if (params.status) queryParams.append('status', params.status);
      if (params.page) queryParams.append('page', params.page);
      if (params.limit) queryParams.append('limit', params.limit);

      const response = await apiClient.get(`/qualifications/pending?${queryParams}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  // ===== Customers & Types Management =====
  static async getCustomerTypes() {
    try {
      const response = await apiClient.get(`/customer-types`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  static async updateCustomerType(customerId, customer_type_id) {
    try {
      const response = await apiClient.patch(`/customers/${customerId}/type`, { customer_type_id });
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  static async getCustomers(params = {}) {
    try {
      const query = new URLSearchParams();
      if (params.page) query.append('page', params.page);
      if (params.limit) query.append('limit', params.limit);
      if (params.search) query.append('search', params.search);
      if (params.customer_type_id) query.append('customer_type_id', params.customer_type_id);
      if (params.verification) query.append('verification', params.verification);
      const response = await apiClient.get(`/customers?${query.toString()}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  static async getCustomer(id) {
    try {
      const response = await apiClient.get(`/customers/${id}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  static async verifyCustomerDocument(documentId, status) {
    try {
      const response = await apiClient.patch(`/customer-verifications/${documentId}/verify`, { status });
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  static async getCustomerDocPresignedUrl(documentId) {
    try {
      const response = await apiClient.get(`/customer-verifications/${documentId}/presign`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Get provider profile picture presigned URL
   */
  static async getProviderProfilePictureUrl(providerId) {
    try {
      const response = await apiClient.get(`/providers/${providerId}/profile-picture/presign`);
      return response.data;
    } catch (error) {
      if (error.response?.status === 404) {
        return null; // No profile picture found
      }
      throw error;
    }
  }
}

export default AdminService;
