const express = require('express');
const router = express.Router();
const pool = require('../../config/db');
 const verifyToken = require('../middlewares/verify_token');
const authorizeRole = require('../middlewares/authorizeRole');

router.post('/create-category', verifyToken, authorizeRole(['admin', 'super admin']), async (req, res) => {
  try {
    const { name, category_type } = req.body;
    if (!name) return res.status(400).json({ message: 'Name is required' });
    if (!category_type) return res.status(400).json({ message: 'Category type is required' });

    const sql = 'INSERT INTO service_categories (name , category_type, is_active) VALUES (?, ?, ?)';
    const [result] = await pool.query(sql, [name, category_type, 1]);

    res.status(201).json({ id: result.insertId, name });
  } catch (err) {
    console.error('Error:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

router.get('/get-categories', verifyToken, authorizeRole(['admin', 'super admin']), async (req, res) => {
  try {

    // Pagination implementation
    let { page = 1, limit = 10 } = req.query;
    page = parseInt(page, 10);
    limit = parseInt(limit, 10);

    if (isNaN(page) || page < 1) page = 1;
    if (isNaN(limit) || limit < 1) limit = 10;

    const offset = (page - 1) * limit;

    // Get total count for pagination metadata
    const [[{ total }]] = await pool.query('SELECT COUNT(*) as total FROM service_categories');

    // Fetch paginated results
    const [rows] = await pool.query(
      'SELECT id, name, is_active, category_type FROM service_categories LIMIT ? OFFSET ?',
      [limit, offset]
    );

    res.json({
      category_data: rows,
      pagination: {
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit)
      }
    });
  } catch (err) {
    console.error('Error:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// edit category name
router.put('/edit-category/:id', verifyToken, authorizeRole(['admin', 'super admin']), async (req, res) => {
  try {
    const { id } = req.params;
    const { name, is_active, category_type } = req.body;
    if (!id) return res.status(400).json({ message: 'ID is required' });
    console.log("EDIT CATEGORY ", req.body);
    if (!name) return res.status(400).json({ message: 'Name is required' });

    const sql = 'UPDATE service_categories SET name = ?, is_active = ?, category_type = ? WHERE id = ?';
    const [result] = await pool.query(sql, [name, is_active, category_type, id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Category not found' });
    }

    res.json({ id, name });
  } catch (err) {
    console.error('Error:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

router.delete('/delete-category/:id', verifyToken, authorizeRole(['admin', 'super admin']), async (req, res) => {
  try {
    const { id } = req.params;

    const sql = 'DELETE FROM service_categories WHERE id = ?';
    const [result] = await pool.query(sql, [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Category not found' });
    }

    res.json({ message: 'Category deleted successfully' });
  } catch (err) {
    console.error('Error:', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});


router.post('/create-sub-category', verifyToken, authorizeRole(['admin', 'super admin']), async (req, res) => {
    try {
        
        console.log(req.body);
        const { name, category_id, description, base_price } = req.body;
        if (!name || !category_id) {
            return res.status(400).json({ message: 'Name and category_id are required' });
        }
        const sql = `INSERT INTO subcategories (name, category_id, description, base_price)
         VALUES (?, ?, ?, ?)`;
        const [result] = await pool.query(sql, [name, category_id, description || null, base_price || null]);
        res.status(201).json({ id: result.insertId, name, category_id, description, base_price });
    } catch (err) {
        console.error('Error:', err);
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});
router.get('/sub-categories', verifyToken, authorizeRole(['admin', 'super admin']), async (req, res) => {
    try {
        const { categoryId } = req.query;
        console.log("categoryId from query:", categoryId);
        const sql = 'SELECT * FROM subcategories WHERE category_id = ?';
        const [rows] = await pool.query(sql, [categoryId]);
        res.json(rows);
    } catch (err) {
        console.error('Error:', err);
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});


router.get('/sub-categories/:id', verifyToken, authorizeRole(['admin', 'super admin']), async (req, res) => {
    try {
        const { id } = req.params;
        const sql = 'SELECT * FROM subcategories WHERE id = ?';
        const [rows] = await pool.query(sql, [id]);
        if (rows.length === 0) {
            return res.status(404).json({ message: 'Subcategory not found' });
        }
        res.json(rows[0]);
    } catch (err) {
        console.error('Error:', err);
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

router.put('/:category_id/subcategories/:id', verifyToken, authorizeRole(['admin', 'super admin']), async (req, res) => {
    try {
        const { category_id, id } = req.params;
        console.log("Updating subcategory with ID:", id, "in category:", category_id);
        const { name, description, base_price } = req.body;
        const sql = `UPDATE subcategories SET name = ?, category_id = ?, description = ?, base_price = ? 
                    WHERE id = ? AND category_id = ?`;
        const [result] = await pool.query(sql, [name, category_id, description, base_price, id, category_id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Subcategory not found' });
        }
        res.json({ id, name, category_id, description, base_price });
    } catch (err) {
        console.error('Error:', err);
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});
router.delete('/delete-sub-category/:categoryId/:subcategoryId', verifyToken, authorizeRole(['admin', 'super admin']), async (req, res) => {
    try {
        const { categoryId, subcategoryId } = req.params;
        const sql = 'DELETE FROM subcategories WHERE id = ? AND category_id = ?';
        const [result] = await pool.query(sql, [subcategoryId, categoryId]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Subcategory not found' });
        }
        res.json({ message: 'Subcategory deleted successfully' });
    } catch (err) {
        console.error('Error:', err);
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});
 

module.exports = router;