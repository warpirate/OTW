/**
 * Test script for email OTP service
 * Run with: node test/test-email-service.js
 */

require('dotenv').config();
const { verifyTransporter, generateOTP, sendOTPEmail } = require('../services/emailService');

async function testEmailService() {
    console.log('🧪 Testing Email OTP Service...\n');

    // Test 1: Verify transporter configuration
    console.log('1. Testing email transporter configuration...');
    const isReady = await verifyTransporter();
    
    if (!isReady) {
        console.error('❌ Email service not configured properly');
        console.error('Please check your USER_GMAIL and USER_PASSWORD environment variables');
        return;
    }
    console.log('✅ Email service configuration is valid\n');

    // Test 2: Generate OTP
    console.log('2. Testing OTP generation...');
    const otp = generateOTP();
    console.log(`✅ Generated OTP: ${otp}`);
    console.log(`✅ OTP length: ${otp.length} digits\n`);

    // Test 3: Send test OTP email (only if test email provided)
    const testEmail = process.env.TEST_EMAIL;
    if (testEmail) {
        console.log('3. Testing OTP email sending...');
        console.log(`📧 Sending test email to: ${testEmail}`);
        
        const emailResult = await sendOTPEmail(
            testEmail,
            'Test Customer',
            otp,
            'Test Worker',
            'TEST123',
            'Test Service'
        );

        if (emailResult.success) {
            console.log('✅ Test email sent successfully!');
            console.log(`📧 Message ID: ${emailResult.messageId}`);
            console.log(`🔐 OTP Code: ${otp}`);
            console.log('📬 Please check your email inbox (and spam folder)');
        } else {
            console.error('❌ Failed to send test email');
            console.error(`Error: ${emailResult.error}`);
        }
    } else {
        console.log('3. Skipping email send test (no TEST_EMAIL provided)');
        console.log('💡 To test email sending, add TEST_EMAIL=your@email.com to .env file');
    }

    console.log('\n🎉 Email service test completed!');
}

// Run the test
testEmailService().catch(error => {
    console.error('💥 Test failed with error:', error);
    process.exit(1);
});
